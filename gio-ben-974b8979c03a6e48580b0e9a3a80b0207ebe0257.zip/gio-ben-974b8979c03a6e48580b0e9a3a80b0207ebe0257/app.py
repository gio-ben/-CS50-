import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # User name for the session
    username_list = db.execute("SELECT username, cash from users WHERE (id = ?)", session["user_id"])
    # Check for invalid user
    if not username_list:
        return apology("User not found", 400)

    # Username
    username = username_list[0]["username"]
    # Remaining cash for the user
    cash = username_list[0]["cash"]

    # Owned stocks
    stocks_list = db.execute("SELECT stock_symb, shares_tot, price_tot from totals WHERE user_id = (SELECT id from users WHERE username = ?)", username)

    total = {}
    actual_price_stock = {}
    for stock in stocks_list:
         actual_price_stock[stock["stock_symb"]] = lookup(stock["stock_symb"])
         total[stock["stock_symb"]] = (actual_price_stock[stock["stock_symb"]]["price"] * stock["shares_tot"])

    # Multiply the actual cost of the shares for the shares_tot
    # Loopare per ogni symb


    return render_template("home.html", cash=cash, stocks = stocks_list, act_price_stock = actual_price_stock, total=total, usd=usd)



@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        # take the symbol and number
        symbol = request.form.get("symbol")
        shares_f = request.form.get("shares")
        if shares_f.isdigit() and int(shares_f) == float(shares_f) and int(shares_f) >= 0:
            shares = int(shares_f)
            # dictionary with the symbol and the price
            price = lookup(symbol)
            # If symbol doesn't exist
            if not price:
                return apology("Provide a valid symbol", 400)   # Modifica il messaggio di errore
            # Cost of the action
            costs = price["price"] * (shares)

            # db.execute per: aggionare il valore del cash e inserire l'azione
            # Quanti soldi ha prima di acquistare
            cash_list = db.execute("SELECT cash from users WHERE id = ?", session["user_id"])
            cash = cash_list[0]["cash"]

            # Può acquistare l'azione?
            if cash < costs:
                return apology("Not enough money", 400)
            # Quanti soldi ha dopo l'acquisto?
            db.execute("UPDATE users SET cash = ? WHERE id = ?", cash-costs, session["user_id"])

            # insert the stock
            db.execute("INSERT into stocks (user_id, stock_symb, shares, price, type, transaction_date) VALUES (?, ?, ?, ?, ?, CURRENT_DATE)", session["user_id"], symbol, shares, price["price"], "+")

            #update totals
            shares_tot_list = db.execute("SELECT shares_tot FROM totals WHERE stock_symb = ? AND user_id = ?", symbol, session["user_id"])
            if not shares_tot_list:
                db.execute("INSERT into totals (user_id, stock_symb, price_tot, shares_tot) VALUES (?, ?, ?, ?)", session["user_id"], symbol, costs, shares)
                return redirect("/")

            shares_tot = shares_tot_list[0]["shares_tot"] + shares
            db.execute("UPDATE totals SET shares_tot = ? WHERE stock_symb = ? AND user_id = ?", shares_tot, symbol, session["user_id"])

            flash("Bought!")
            return redirect("/")
        else:
            return apology("Invalid number", 400)

    else:
        return render_template("buy.html", buy=True, sell=False)



@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    # SELECT * from TABLE history
    # TABLE history: id primary KEY, user_id, n_stocks, data
    if request.method == "GET":

        history_buys = db.execute("SELECT * from stocks WHERE user_id = ?",
                             session["user_id"])
        history_sells = db.execute("SELECT * from sells WHERE user_id = ?",
                             session["user_id"])

        history =  history_buys + history_sells



        return render_template("history.html", history = history, usd=usd)

# Mettere a posto la pagina su html, perché ora mostra solo due parentesi



@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    # if get = display a form for stock quote
    if request.method == "POST":
        symbol = request.form.get("symbol")
        quote = lookup(symbol)
        if not quote:
            return apology("Provide a valid symbol", 400)   # Modifica il messaggio di errore
        return render_template("quote.html", quote=quote, usd=usd)
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":

        username = request.form.get("username")
        if not username:
            return apology("Provide a username", 400)
        existing_users = db.execute("SELECT username from users where username = ?", username)
        if existing_users:
            return apology("Username already taken", 400)

        password = request.form.get("password")
        if not password:                                 # Better check for special characters
            return apology("Provide a password", 400)
        confirmation = request.form.get("confirmation")
        if not confirmation:
            return apology("Check the password", 400)

        # Confirmation of psw
        # confirmation = request.form.get("confirmation")
        # if not confirmation:
        # else check hash
        if password != confirmation:
            return apology("Different password", 400)

        hashed_psw = generate_password_hash(password, method='pbkdf2', salt_length=16)
        db.execute("INSERT into users (username, hash) VALUES (?, ?)", username, hashed_psw)
        return redirect("/login")

    else:
        return render_template ("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    if request.method == "POST":
        # take the symbol and number
        symbol = request.form.get("symbol")
        shares = int(request.form.get("shares"))

        # dictionary with the symbol and the price
        price = lookup(symbol)
        # If symbol doesn't exist
        if not price:
            return apology("Provide a valid symbol", 400)   # Modifica il messaggio di errore
        # Cost of the action
        costs = price["price"] * shares

        # db.execute per: aggionare il valore del cash e inserire l'azione nella lista vendite
        # Quanti soldi ha prima di acquistare
        cash_list = db.execute("SELECT cash from users WHERE id = ?", session["user_id"])
        cash = cash_list[0]["cash"]
        # Quanti soldi ha dopo l'acquisto?
        db.execute("UPDATE users SET cash = ? WHERE id = ?", cash+costs, session["user_id"])

        # insert the stock into the sell database
        db.execute("INSERT into sells (user_id, stock_symb, shares, price, type, transaction_date) VALUES (?, ?, ?, ?, ?, CURRENT_DATE)", session["user_id"], symbol, shares, price["price"], "-")
        # Update the total shares of the user
        shares_tot_list = db.execute("SELECT shares_tot FROM totals WHERE stock_symb = ? AND user_id = ?", symbol, session["user_id"])
        shares_tot = shares_tot_list[0]["shares_tot"] - shares
        if shares_tot < 0:
            return apology("You don't have enough shares", 400)
        db.execute("UPDATE totals SET shares_tot = ? WHERE stock_symb = ? AND user_id = ?", shares_tot, symbol, session["user_id"])

        flash("Sold!")
        return redirect("/")
    else:
        stocks = db.execute("SELECT stock_symb from totals WHERE user_id = ?", session["user_id"])
        return render_template("buy.html", buy=False, sell=True, stocks = stocks)
